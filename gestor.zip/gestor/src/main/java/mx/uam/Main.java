package mx.uam;

public class Main {
    public static void main(String[] args) {
        
        
        Persona p2 = new Persona(1,'f',"Luisa",18,50);
        
        System.out.println(p2);

    }
}